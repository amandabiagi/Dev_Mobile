package br.com.nina.telalogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Criando o clique do botão entrar
        btnEntrar.setOnClickListener {

            //pegando os dados

            val usuario = edtUsuario.text.toString().trim()
            val senha = edtSenha.text.toString().trim()

            // Condição para verificar se usuário e senha estão corretos

            // verificando se o usuário esta vazio

            if (usuario.isEmpty()) {
                txtResultado.text = "Usuário vazio"
                // Verificando se a senha esta vazio

            } else if (senha.isEmpty()) {
                txtResultado.text = "Senha vazia"

                // verificando se o login esta correto


            } else if (usuario == "AmandaBiagi") {  //(usuario == "AmandaBiagi" && senha == "12345"){

                //Verificando se a senha esta correta

                if (senha == "12345") {
                    txtResultado.text = "Usuario logado"


                } else {
                    txtResultado.text = "Senha Incorreta"
                }

            } else {
                txtResultado.text = "Usuario Incorreto"
            }
        }
    }
}